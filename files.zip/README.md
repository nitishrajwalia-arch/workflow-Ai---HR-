# Marbella HR

A standalone people system for Marbella Group. One file, no procurement, no dead buttons.

`MarbellaHR.jsx` — 7,300 lines, one default export, `React + lucide-react` and nothing else.
No charting library, no state library, no CSS framework.

---

## Run it

```bash
npm i react react-dom lucide-react
# drop MarbellaHR.jsx into src/, then:
import App from "./MarbellaHR.jsx";
```

It mounts on its own. There is no login, no router and no backend — HR is signed in as
Simran Kaur (HR Head) and every screen is reachable from the left rail.

---

## What is in it

| Tab | What it does |
|---|---|
| **HR Desk** | Landing. Headcount, cards issued, letters sent, open exits, ledger health. Birthdays and work anniversaries in the next 10 days. A "needs your attention" list — people with no personal number, no photo, companies with no GSTIN, projects not RERA registered. |
| **The desk** | 20 branded letter templates. Search an employee ID → it tells you who employs them and since when → pick a letter → it merges name, company, dates, manager → pick the letterhead → print, email or file. |
| **Population** | 200 people. Filter by project or see the whole group. Shows **who employs them**, where they're posted, when they joined and their department's hours. Split by payroll company. |
| **Org chart** | CSS 3D board. Drag to rotate, click to open, colour-coded by department, headcount per manager, breadcrumb to the top, job description inline. |
| **Card bureau** | Issue and re-issue Marbella ID cards. Two deliberately unequal paths — see below. |
| **Bulk intake** | Paste a sheet, columns auto-match, every row validated, failures held back with a reason. |
| **Companies** | Legal entities and the projects under them. GSTIN and RERA per entity/project. |
| **Job descriptions** | 53 distinct roles on the roster. Pick one, get a drafted description, edit it, save it. |
| **Working hours** | Each department's own clock, set by its own manager. Store opens 08:00, Accounts 10:00. |
| **Exits & F&F** | Six-stage deboarding flowchart with the tamper-evident ledger. |
| **Usage** | Counts every action so you can see which parts get used. |

---

## The two decisions that shape this build

### 1. A project is not an employer

Marbella Grand and Twin Towers are both **Delhi Punjab Real Estates LLP**. Curo One and
Royce are both **D.R. Developers & Colonisers**. Security and labour sit on **SRG**.

So a person has two separate fields:

- `office` — the project they're **posted at**
- `employer` — the legal entity that **pays them**

Get this wrong and the relieving letter goes out on the wrong letterhead, the PF challan
names the wrong company, and the experience certificate is worthless. Every letter in
The desk defaults to the person's `employer`, and warns if you pick a different entity.

### 2. Re-issuing a card is not a printing job

A card opens doors that are shut to outsiders, so the two paths are deliberately unequal:

- **Old card handed back** → pick the fault, tick "received and destroyed", name the receiver, authorise. Seconds.
- **Lost / stolen / not returned** → three steps: circumstances in the holder's own words (25-character floor, "lost it" won't pass), when it was last in hand, who they told, FIR number if stolen, then five undertakings ticked individually, then a summary, then authorisation.

Either way the old card is cancelled and a new version issued. Anyone on their third card
is flagged as a pattern worth a conversation.

---

## Be honest about these — do not oversell them to the client

| Thing | What is real | What is not |
|---|---|---|
| **Ledger** | Each entry is sealed with a fingerprint of itself + the one before it. Edit any past entry and every seal after it breaks; the Verify badge turns red. Tested: edit → breaks, reseal that one entry → **the next one still breaks**, delete → breaks, honest append → stays valid. | It is **tamper-evident, not tamper-proof.** This runs in the browser. Anyone who opens the file can rewrite the state and recompute the chain. Real immutability needs a server the user does not control, append-only DB permissions, and signing keys that never reach the browser. |
| **Authorisation code** | Blocks the action, wrong code refused, default `marbella`. | Checked in the browser. Stops a colleague printing from someone else's screen. **Not access control.** Enforcement belongs on the printer's server. |
| **OTP** | Six digits, two-minute expiry, wrong/expired code refused, verification recorded. | The code is **shown on screen** because sending SMS/email needs a gateway. |
| **Email a letter** | The merge, the letterhead, the record that it went out. | The send. Needs a mail service. |
| **Salary** | Structure, gross/net, F&F computation. | Sits in the file in **plain text**. |
| **GSTIN** | Shape checked strictly. State code and PAN read out of the number. | The **check character is a warning, never a block.** My check-digit maths agreed with only some published sample GSTINs and I could not establish whether the arithmetic or the samples were wrong — so a real registration is never rejected on my uncertainty. Only the GST portal settles it. All four seeded GSTINs are placeholders and correctly show "needs confirming". |
| **RERA** | Four states — received / applied / not yet / not applicable. Shape checked. | Registration not verified. |
| **Org board** | Real CSS 3D — measured `perspective: 1500px`, cards on `matrix3d`. | **Not a WebGL model.** Chosen so names stay crisp at every angle and it runs on a site office phone. |
| **Photo capture** | Asks for the camera, captures, crops square, saves to the record. | Untested — no camera in the build sandbox. Browsers only grant it on a secure page. |
| **Usage counts** | Every action counted. | Reset on reload. Persisting them is a backend job. |

---

## Data model

```js
person = {
  id, name, designation, dept, type,        // MB-PUR-0012
  joined, dob, status,                      // "active" | "exited"
  office,        // project they are POSTED AT   -> PROJECT_SEED[].id
  employer,      // company that PAYS THEM       -> COMPANY_SEED[].id
  reportsTo,     // another person.id, or null for the root
  perf, photo, shift, notes
}
```

Separate maps, keyed by `person.id`:
`salaries` · `contacts` (personal phone/email only) · `devices` (IMEI, SIM) · `cardLog` · `exits`

Separate maps, keyed by department: `deptRules` (hours) · `leavePolicy` (casual/sick/earned/half-day)

### The context

Every view reads from one `ProcCtx` provider in `App`. Keys:

```
people cardLog ledger salaries devices contacts leavePolicy deptRules
companies projects exits usage docLog jds scope offices hrLog
```

Actions:

```
track logDoc saveJD seal setSalary addDevice dropDevice setContact setLeave
setDeptRule saveCompany saveProject setEmployer updatePerson issueCard
bulkAddPeople openExit advanceExit setScope
```

### Seeds

`PEOPLE_SEED` (19 named leadership) + `buildRoster()` (181 generated, deterministic) = **200 on file, 198 active**
(two are pre-marked exited — that is correct, not a bug).

`buildRoster()` gives the roster a real shape: three ranks, department heads, and labour
reporting to the **site supervisor at their own site** — not to a labour department.
Result: Chairman 16 direct, managers 5–8 each. Never let it flatten back to everyone
reporting to `MB-ADM-0001`; that bug shipped once and looked like a broken tree.

---

## Validation that actually validates

- **Email** — 18 distinct failure messages, not "invalid". Two `@` signs, double dot, leading dot, `.c0m` has digits, `gmial.com` → "did you mean gmail.com", and a company address in the personal field is **rejected** ("the company account is closed the day they leave").
- **IMEI** — Luhn check digit. All seeded IMEIs are genuinely valid; three sample rows were caught and fixed during build.
- **Mobile** — 10 digits, must start 6–9.
- **GSTIN** — see the honesty table.

---

## If you extend it

- **Adding a letter**: push to `TEMPLATES`. Merge fields are `{{name}} {{first}} {{id}} {{designation}} {{dept}} {{company}} {{joined}} {{tenure}} {{years}} {{manager}} {{today}} {{hrName}} {{hrTitle}} {{project}}` plus whatever you list in `fields`. Unfilled blanks render as `‹field›` and **block sending** — keep that.
- **Adding a JD**: push to `JD_LIB` with a `match` array. Order matters — leadership entries sit first so a Chairman doesn't get handed the clubhouse description (that bug shipped once too).
- **Adding a deboarding stage**: push to `EXIT_STAGES`. Stages gate strictly in order; `advanceExit` moves one step and seals the ledger.
- **Filtering the org tree**: never filter the array passed as `all` — that computes both structure *and* headcounts. Pass the full roster and use `reveal`/`dept` to decide what is *shown*. Filtering `all` severs branches and produces phantom counts. This shipped once and the client caught it.

---

## Style rules this codebase follows

- Palette is `C`. Royal blue `#224A85`, gold `#C7A162`, white panels on `#EDF1F7` paper. Never dark-dominant.
- Serif (`serif`) for headings, system sans for everything else, mono for IDs and numbers.
- Copy is plain English, written the way a person would say it. No "Error 402". No exclamation marks. Say what is wrong and what to do.
- Every destructive or irreversible action states its consequence **before** the button, not after.
- No feature is described as more capable than it is. If the send needs a backend, the UI says so on the screen where you'd press send.

---

## Known gaps

- Attendance import beyond the department-hours record.
- Photo capture untested (no camera in the build sandbox).
- Devices are seeded and shown in the exit flow but have no dedicated management screen.
- OTP verification exists as a component but is not yet wired into the person record UI.
- Nothing persists across reload — no backend.
